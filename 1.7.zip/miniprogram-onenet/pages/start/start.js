// start.js

Page({
    data: {

    },
    //跳转到天气页面
    navigate1: function() {
        wx.navigateTo({
            url: '../wifi_station/tianqi/tianqi',
        })
    },

    //跳转到音量页面
    navigate2: function () {
        wx.navigateTo({
           url: '../wifi_station/noise/noise',
        })
    },

    //跳转到有无人页面
    navigate3: function () {
       wx.navigateTo({
           url: '../wifi_station/people/people',
        })
    },

})